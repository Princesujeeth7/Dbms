<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Us - IITG Health Portal</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f4f6f9;
      margin: 0;
      padding: 0;
    }

    .about-container {
      max-width: 900px;
      margin: 50px auto;
      padding: 40px;
      background-color: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .about-container h1 {
      color: #004aad;
      font-size: 2.5rem;
      margin-bottom: 10px;
    }

    .about-container p {
      font-size: 1.1rem;
      line-height: 1.8;
      color: #333;
    }

    .team-names {
      margin-top: 25px;
      font-weight: bold;
      color: #222;
    }

    .branch-info {
      margin-top: 5px;
      color: #555;
      font-style: italic;
    }
  </style>
</head>
<body>

  <div class="about-container">
    <h1>About Us</h1>
    <p>
      Welcome to the IIT Guwahati Online Hospital Portal!<br><br>
      We are a team of passionate undergraduate students from the <strong>Data Science and Artificial Intelligence</strong> branch at <strong>IIT Guwahati</strong>. We have developed this platform using <strong>HTML</strong>, <strong>CSS</strong>, and <strong>PHP</strong> to provide an efficient and user-friendly health portal for our campus.
      <br><br>
      Our aim is to make healthcare access easier, faster, and smarter for all students and staff at IITG.
    </p>

    <div class="team-names">
      Developed by: Sujeeth, Varshith, Yaswanth
    </div>
    <div class="branch-info">
      B.Tech - Data Science and Artificial Intelligence, IIT Guwahati 27
    </div>
    <a href='index.php' class='back-link'>Back_To_Index</a>
  </div>

</body>
</html>
